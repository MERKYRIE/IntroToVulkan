This example creates an SDL window and renderer, then a streaming texture that
it will update every frame before drawing it to the screen.

