This example creates an SDL window and renderer, loads a texture
from a .bmp file, and then draws it a few times each frame, adjusting
the viewport before each draw.

